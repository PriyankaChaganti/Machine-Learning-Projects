Project Name: Implement the Adaboost algorithm and a Gini-index based method for learning decision stumps

Source code: HW3_Chaganti.ipynb
Application used for developing: Jupyter

What's on the zip file:
1. HW3_Chaganti.ipynb : Source Code
2. TrainData.txt : Train Data
3. TestData.txt: Test Data
4. HW3_Report.pdf: Report
5. Predictions.dat: Contains the output of the source code file

How to run the file:
1. User should have Python installed on their system
2. Packages to be imported: nltk, pandas, numpy, sklearn
3. HW3_Chaganti.ipynb contains the source code of the Project
