#!/usr/bin/env python
# coding: utf-8

# In[165]:


import pandas as pd
import numpy as np
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import f1_score
from sklearn.model_selection import train_test_split


# In[166]:


Train_Dataset = pd.read_csv("TrainData.txt", header = None)
Test_Dataset = pd.read_csv("TestData.txt", header = None)
Train_Dataset


# In[167]:


train_pred = Train_Dataset[0]
train_pred


# In[168]:


train_data = Train_Dataset.drop([0], axis = 1)
train_data


# In[169]:


class AdaBoost:
    
    def __init__(self):
        self.alphas = []
        self.G_M = []
        self.M = None
        self.training_errors = []
        self.prediction_errors = []

    def fit(self, X, y, M):
        self.alphas = [] 
        self.training_errors = []
        self.M = M
        for m in range(0, M):
            if m == 0:
                w_i = np.ones(len(y)) * 1 / len(y) 
            else:
                w_i = update_weights(w_i, alpha_m, y, y_pred)
            G_m = DecisionTreeClassifier(max_depth = 1)    
            G_m.fit(X, y, sample_weight = w_i)
            y_pred = G_m.predict(X)
            
            self.G_M.append(G_m) 
            error_m = compute_error(y, y_pred, w_i)
            self.training_errors.append(error_m)


            alpha_m = compute_alpha(error_m)
            self.alphas.append(alpha_m)

        assert len(self.G_M) == len(self.alphas)
        
    def predict(self, X):
        weak_preds = pd.DataFrame(index = range(len(X)), columns = range(self.M)) 

        for m in range(self.M):
            y_pred_m = self.G_M[m].predict(X) * self.alphas[m]
            weak_preds.iloc[:,m] = y_pred_m

        y_pred = (1 * np.sign(weak_preds.T.sum())).astype(int)

        return y_pred


# In[170]:


def compute_error(y, y_pred, w_i):
    return (sum(w_i * (np.not_equal(y, y_pred)).astype(int)))/sum(w_i)

def compute_alpha(error):
    return np.log((1 - error) / error)

def update_weights(w_i, alpha, y, y_pred):
    return w_i * np.exp(alpha * (np.not_equal(y, y_pred)).astype(int))


# In[171]:


df = pd.read_csv('TrainData.txt', header = None)
print(df[0])
df[0]=df[0].replace({3:-1,5:1})   
X_train, X_test, y_train, y_test = train_test_split(df.drop(columns = 0).values, df[0].values,train_size = 0.7,random_state = 42)


# In[172]:


ab = AdaBoost()
ab.fit(X_train, y_train, M = 1500)
train_out = ab.predict(X_test)
train_out


# In[173]:


test_data = Test_Dataset.replace({3:-1,5:1})
print(test_data)


# In[174]:


prediction = ab.predict(test_data)
prediction


# In[175]:


train_output = train_out.replace({-1:3,1:5})
final_prediction = prediction.replace({-1:3,1:5})
print(prediction)
print(train_out)
print(train_pred)


# In[176]:


from sklearn.metrics import f1_score
f1_score(y_test,train_out)


# In[177]:


def accuracy(y_actual, y_pred):
        accuracy = np.sum(y_actual == y_pred) / len(y_actual)
        return accuracy


total = accuracy(y_test,train_out)
total


# In[178]:


pd.DataFrame(final_prediction).to_csv("prediction.txt", index=False,header=False)


# In[179]:


import matplotlib.pyplot as plt
plt.plot(ab.training_errors)


# In[180]:


error = 1 - total
error


# In[186]:


plt.plot(error)
plt.plot(ab.training_errors, color = 'orange')
plt.hlines(0.46, 0, 400, colors = 'red', linestyles='dashed')


# In[182]:


def calculate_error(y, y_pred, w_i):
   
    return (sum(w_i * (np.not_equal(y, y_pred)).astype(int)))/sum(w_i)

error = round(compute_error(y_test, train_out, np.ones(len(y_test))), 4)
plt.plot(error)


# In[183]:


from sklearn import tree
clf = tree.DecisionTreeClassifier()
clf = clf.fit(X_train, y_train)
values = clf.predict(X_test)


# In[184]:


initial = 0
for i in range(len(values)):
    if values[i] == y_test[i]:
        initial+= 1

initial        
accuracy =  initial/len(values)
error = 1-accuracy
error


# In[185]:


plt.plot(error)

