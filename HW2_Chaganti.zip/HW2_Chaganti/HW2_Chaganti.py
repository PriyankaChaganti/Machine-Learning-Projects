#!/usr/bin/env python
# coding: utf-8

# In[790]:


import pandas as pd
import numpy as np
import random
import time
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import log_loss
import warnings
warnings.filterwarnings('ignore')
from sklearn.metrics import f1_score
from sklearn.metrics import confusion_matrix, accuracy_score
from sklearn.metrics import roc_auc_score

from sklearn.linear_model import LogisticRegression


# In[791]:


train = pd.read_csv('cleveland-train.csv') 
train


# In[792]:


X = (train[['age','sex','cp','trestbps','chol','fbs','restecg','thalach','exang','oldpeak','slope','ca','thal']])
X


# In[793]:


Y = np.array(train['heartdisease::category|-1|1'])
Y


# In[794]:


scaler = StandardScaler()
normalized_data = scaler.fit_transform(X)
normalized_data


# norm = MinMaxScaler().fit(X)
# normalized_data = norm.transform(X)
# normalized_data


# In[795]:


b = random.random()
w = np.random.rand(normalized_data.shape[1])
print(b,w)


# In[796]:


def sigmoid(b,w,normalized_data):
    return (1.0/(1+np.exp(-(b+np.matmul(normalized_data,w)))))

pred = sigmoid(b,w,normalized_data)
pred


# In[797]:


for i in range(len(pred)):
    if pred[i] <= 0.5:
        pred[i] = -1
    else:
        pred[i] = 1

pred


# In[798]:


Y


# In[ ]:





# In[799]:


def partial_deriv(b1, w1, Y, pred, normalized_data, Q_eta):
    b_derv = np.sum(pred-Y)/len(Y)
    b1 = b1 - Q_eta * b_derv
    w_derv = np.dot((pred-Y),normalized_data)/len(Y)
    w1 = w1 - Q_eta * w_derv

    return b1,w1


Q_eta = 0.00001
b,w = partial_deriv(b, w, Y, pred, normalized_data, Q_eta)
print(b,w)


# In[800]:


epochs = 10000
initial = time.time() 
b = random.random()
w = np.random.rand(normalized_data.shape[1])
print(b,w)
for i in range(epochs):
    pred = sigmoid(b,w,normalized_data)
    cost = log_loss(Y,pred)
    b1 = b
    w1 = w
    b_derv = np.sum(pred-Y)/len(Y)
    w_derv = np.dot((pred-Y),normalized_data)/len(Y)
    if(np.all(w_derv)<= 10**-3):
        break
    b = b - epochs * b_derv
    w = w - epochs * w_derv
end = time.time()
print("Final values:",b,w)
print("Total time taken is :",end-initial)


# In[ ]:





# In[801]:


# # For Report
# # Iterations
# epochs = 100000
# initial = time.time() 
# b = random.random()
# w = np.random.rand(normalized_data.shape[1])
# print(b,w)
# for i in range(epochs):
#     pred = sigmoid(b,w,normalized_data)
#     cost = log_loss(Y,pred)
#     b1 = b
#     w1 = w
#     b_derv = np.sum(pred-Y)/len(Y)
#     w_derv = np.dot((pred-Y),normalized_data)/len(Y)
#     if(np.all(w_derv)<= 10**-3):
#         break
#     b = b - epochs * b_derv
#     w = w - epochs * w_derv
# end = time.time()
# print("Final values:",b,w)
# print("Total time taken is :",end-initial)


# In[802]:


# For Report
# Iterations
# epochs = 1000000
# initial = time.time() 
# b = random.random()
# w = np.random.rand(normalized_data.shape[1])
# print(b,w)
# for i in range(epochs):
#     pred = sigmoid(b,w,normalized_data)
#     cost = log_loss(Y,pred)
#     b1 = b
#     w1 = w
#     b_derv = np.sum(pred-Y)/len(Y)
#     w_derv = np.dot((pred-Y),normalized_data)/len(Y)
#     if(np.all(w_derv)<= 10**-3):
#         break
#     b = b - epochs * b_derv
#     w = w - epochs * w_derv
# end = time.time()
# print("Final values:",b,w)
# print("Total time taken is :",end-initial)


# In[803]:


predictions = b + np.dot(normalized_data,w)
predictions


# In[804]:


log_loss(Y,predictions)


# In[805]:


for i in range(len(predictions)):
    if predictions[i] <= 0.5:
        predictions[i] = -1
    else:
        predictions[i] = 1

predictions


# In[806]:


# f1_score(Y,predictions)

# accuracy_score(Y, predictions)

roc_auc_score(Y, predictions)


# In[807]:


#For Test Data
test = pd.read_csv('cleveland-test.csv') 
test


# In[808]:


scaler = StandardScaler()
normalized_test = scaler.fit_transform(test)
normalized_test


# normalized_test = norm.transform(test)
# normalized_test


# In[809]:


pred_test = b+ np.dot(normalized_test,w)


for i in range(len(pred_test)):
    if pred_test[i] <= 0.5:
        pred_test[i] = -1
    else:
        pred_test[i] = 1

pred_test


# In[810]:


# fptr = open("./PredictionsStandard3.dat", 'w')
# for prediction in pred_test:
#     if prediction > 0:
#         fptr.write('1\n')
#     else:
#         fptr.write('-1\n')
# fptr.close()


# In[811]:


for i in range(len(pred)):
    if pred[i] <= 0.5:
        pred[i] = -1
    else:
        pred[i] = 1

pred


# In[812]:


# # Using HW1 Logistic Regression Library
initial = time.time() 
regressor = LogisticRegression(penalty='l2',max_iter=100,C = 2.4110535042865755)
regressor.fit(normalized_data,pred)
predictions = regressor.predict(normalized_test)

predictions
end = time.time() 
print("Total Time taken is:", (end-initial))


# In[ ]:





# In[813]:


fptr = open("./PredHW1compare.dat", 'w')
for prediction in pred_test_manual:
    if prediction > 0:
        fptr.write('1\n')
    else:
        fptr.write('-1\n')
fptr.close()


# In[814]:


# Manual Normalization
X_manual = X.copy()
for column in X_manual.columns:
    X_manual[column] = (X_manual[column] - X_manual[column].mean())/X_manual[column].std()    
display(X_manual)


# In[815]:


b = random.random()
w = np.random.rand(X_manual.shape[1])
print(b,w)


# In[816]:


pred_manual = sigmoid(b,w,X_manual)
pred_manual


# In[817]:


for i in range(len(pred_manual)):
    if pred_manual[i] <= 0.5:
        pred_manual[i] = -1
    else:
        pred_manual[i] = 1

pred_manual


# In[818]:


epochs = 10000
Q_eta = 0.000001
b,w = partial_deriv(b, w, Y, pred_manual, X_manual, Q_eta)
initial = time.time() 
b = random.random()
w = np.random.rand(X_manual.shape[1])
print(b,w)
for i in range(epochs):
    pred = sigmoid(b,w,X_manual)
    cost = log_loss(Y,pred_manual)
    b1 = b
    w1 = w
    b_derv = np.sum(pred_manual-Y)/len(Y)
    w_derv = np.dot((pred_manual-Y),X_manual)/len(Y)
    if(np.all(w_derv)<= 10**-3):
        break
    b = b - epochs * b_derv
    w = w - epochs * w_derv
end = time.time()
print("Final values:",b,w)
print("Total Time taken:",end-initial)
predictions_manual = b + np.dot(X_manual,w)
predictions_manual


# In[819]:


# epochs = 100000
# Q_eta = 0.000001
# b,w = partial_deriv(b, w, Y, pred_manual, X_manual, Q_eta)
# initial = time.time() 
# b = random.random()
# w = np.random.rand(X_manual.shape[1])
# print(b,w)
# for i in range(epochs):
#     pred = sigmoid(b,w,X_manual)
#     cost = log_loss(Y,pred_manual)
#     b1 = b
#     w1 = w
#     b_derv = np.sum(pred_manual-Y)/len(Y)
#     w_derv = np.dot((pred_manual-Y),X_manual)/len(Y)
#     if(np.all(w_derv)<= 10**-3):
#         break
#     b = b - epochs * b_derv
#     w = w - epochs * w_derv
# end = time.time()
# print("Final values:",b,w)
# print("Total Time taken:",end-initial)
# predictions_manual = b + np.dot(X_manual,w)
# predictions_manual


# In[820]:


# epochs = 1000000
# Q_eta = 0.000001
# b,w = partial_deriv(b, w, Y, pred_manual, X_manual, Q_eta)
# initial = time.time() 
# b = random.random()
# w = np.random.rand(X_manual.shape[1])
# print(b,w)
# for i in range(epochs):
#     pred = sigmoid(b,w,X_manual)
#     cost = log_loss(Y,pred_manual)
#     b1 = b
#     w1 = w
#     b_derv = np.sum(pred_manual-Y)/len(Y)
#     w_derv = np.dot((pred_manual-Y),X_manual)/len(Y)
#     if(np.all(w_derv)<= 10**-3):
#         break
#     b = b - epochs * b_derv
#     w = w - epochs * w_derv
# end = time.time()
# print("Final values:",b,w)
# print("Total Time taken:",end-initial)
# predictions_manual = b + np.dot(X_manual,w)
# predictions_manual


# In[821]:


# for i in range(len(predictions_manual)):
#     if predictions_manual[i] <= 0.5:
#         predictions_manual[i] = -1
#     else:
#         predictions_manual[i] = 1

# predictions_manual


# In[822]:


# log_loss(Y,predictions_manual)


# In[823]:


accuracy_score(Y, predictions_manual)

# f1_score(Y,predictions_manual)

# roc_auc_score(Y, predictions_manual)


# In[ ]:





# In[ ]:





# In[824]:


test_manual = test.copy()
for column in test_manual.columns:
    test_manual[column] = (test_manual[column] - test_manual[column].mean())/test_manual[column].std()    
display(test_manual)


# In[ ]:





# In[825]:


pred_test_manual = b + np.dot(test_manual,w)
pred_test_manual


# In[826]:


for i in range(len(pred_test_manual)):
    if pred_test_manual[i] <= 0.5:
        pred_test_manual[i] = -1
    else:
        pred_test_manual[i] = 1

pred_test_manual


# In[827]:


fptr = open("./Manual_Predictions3.dat", 'w')
for prediction in pred_test_manual:
    if prediction > 0:
        fptr.write('1\n')
    else:
        fptr.write('-1\n')
fptr.close()

