Project Name: Implement an optimization method (gradient descent) that allows you to train logistic regression models.

Source code: HW2_Chaganti.ipynb
Application used for developing: Jupyter

What's on the zip file:
1. HW2_Chaganti.ipynb : Source Code
2. cleveland-train.csv : Train Data
3. cleveland-test.csv: Test Data
4. HW2_Report.pdf: Report
5. PredictionsStandard1.dat: Contains the output of the source code file

How to run the file:
1. User should have Python installed on their system
2. Packages to be imported: nltk, pandas, numpy, sklearn
3. HW2_Chaganti.ipynb contains the source code of the Project
4. The code would generate various predictions file based on the scaler or the iterations that are to be run, but currently considering only the prediction file that
generated the best output. The other prediction files are given under separate sub-folder "Predictions" for reference.
