Project Name: A practical application in e-commerce applications
is to infer sentiment (or polarity) from free form review text submitted for range of products.
Source code: HW1_Chaganti.ipynb
Application used for developing: Jupyter

What's on the zip file:
1. HW1_Chaganti.ipynb : Source Code
2. train_file : Train Data
3. test.dat: Test Data
4. Assignment 1 Report.pdf: Report
5. Predictions.dat: Contains the output of the source code file

How to run the file:
1. User should have Python installed on their system
2. Packages to be imported: nltk, pandas, numpy, sklearn
3. HW1_Chaganti.ipynb contains the source code of the Project
